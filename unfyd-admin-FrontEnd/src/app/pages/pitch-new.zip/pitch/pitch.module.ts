import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PitchRoutingModule } from './pitch-routing.module';
import { PitchComponent } from './pitch.component';


@NgModule({
  declarations: [
    PitchComponent
  ],
  imports: [
    CommonModule,
    PitchRoutingModule
  ]
})
export class PitchModule { }
