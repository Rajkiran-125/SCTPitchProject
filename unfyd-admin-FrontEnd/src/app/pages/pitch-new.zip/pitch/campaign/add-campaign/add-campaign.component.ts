import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/global/api.service';
import { AuthService } from 'src/app/global/auth.service';
import { CommonService } from 'src/app/global/common.service';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from 'src/app/components/dialog/dialog.component';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-campaign',
  templateUrl: './add-campaign.component.html',
  styleUrls: ['./add-campaign.component.scss']
})
export class AddCampaignComponent implements OnInit {
    formName: any;
    selectedTab: any;
    form: FormGroup;
    userDetails: any;
    requestObj: any;
    language: any;
    botFlowList: any;
    submittedForm: boolean = false;
    loader: boolean = false;
    formData: any = null;
    path: any;
    channelSRCID: any;
    productId: any;
  campaginData: any;
  config: any;

  constructor(
    private fb: FormBuilder,
    private api: ApiService,
    private formBuilder: FormBuilder,
    public common: CommonService,
    private auth: AuthService,
    public datepipe: DatePipe,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog) { }

  ngOnInit(): void {
    this.userDetails = this.auth.getUser();
    this.path = this.activatedRoute.snapshot.paramMap.get('id');
    this.channelSRCID = this.activatedRoute.snapshot.paramMap.get('uniqueid');
    this.productId = this.activatedRoute.snapshot.paramMap.get('productId');
    // this.type = this.activatedRoute.snapshot.paramMap.get('type');
    this.getLanguage();

    this.form = this.formBuilder.group({
      CampaignStartDate:['', [Validators.nullValidator]],
      CampaignEndDate:['', [Validators.nullValidator]],
    });

    this.form = this.formBuilder.group({

      CampaignName: ['', [Validators.required]],
      CampaignDesc: [' ', [Validators.required]],
      CampaignType: ['One Time', [Validators.required]],
      ChannelList: ['Whatsapp', [Validators.required]],
      ChannelSrc: ['', [Validators.required]],
      toggleMultilingual: ['', [Validators.required]],
      targetAudienceList: ['', [Validators.required]],
      themeColorCode: ['', [Validators.required]],
      themePrimaryColorCode: ['', [Validators.required]],
      themeSecondaryColorCode: ['', [Validators.required]],
      eyeCatcherHeading: ['Hi, There!!', [Validators.required]],
      eyeCatcherText: ['Welcome', [Validators.required]],
      eyeCatcher: ['', [Validators.required]],
      chatIconStyle: ['', [Validators.required]],
      chatButtonPosition: ['', [Validators.required]],
      chatTitleOnline: ['', [Validators.required]],
      chatTitleOffline: ['', [Validators.required]],
      sideSpacing: ['', [Validators.required]],
      agentAvatar: ['', [Validators.nullValidator]],
      agentAvatarUploaded: ['', [Validators.nullValidator]],
      botAvatarUploaded: ['', [Validators.nullValidator]],
      bottomSpacing: ['', [Validators.required]],
      languageSelected: ['', [Validators.required]],
      toggleAttachment: ['', [Validators.required]],
      maxNumberFile: ['', [Validators.nullValidator]],
      fileNumber: ['singleFile', [Validators.nullValidator]],
      sendFileType: ['', [Validators.nullValidator]],
      FileFormatSelected: [['jpg','png','pdf'], [Validators.nullValidator]],
      singleMultiImage: ['singleFile', [Validators.nullValidator]],
      fileSize: ['1', [Validators.nullValidator]],
      fileSizeMemorySelected: ['MB', [Validators.nullValidator]],
      toggleMic: [false, [Validators.nullValidator]],
      toggleEmoji: [true, [Validators.nullValidator]],
      toggleInputForm: ['', [Validators.nullValidator]],
      toggleCarousel: ['', [Validators.nullValidator]],
      //inputFormLayout: ['', [Validators.nullValidator]],
      toggleBotFlow: ['', [Validators.nullValidator]],
      botAvatar: ['', [Validators.nullValidator]],
      botFlowSelected: ['', [Validators.nullValidator]],
      carousalStyle: ['', [Validators.nullValidator]],
      urlToggle: ['', [Validators.nullValidator]],
      chatButtonShape: ['', [Validators.nullValidator]],
      chatIconUploaded: ['', [Validators.nullValidator]],
      viewSingleMultiImage: ['', [Validators.nullValidator]],
      imageCaption: [true, [Validators.nullValidator]],
      videoPlayback: [true, [Validators.nullValidator]],
      audioPlayback: [true, [Validators.nullValidator]],
      pictureInPicture: [true, [Validators.nullValidator]],
      urlHighlighter: ['blue', [Validators.nullValidator]],
      emailHighlighter: ['blue', [Validators.nullValidator]],
      numberHighlighter: ['blue', [Validators.nullValidator]],
      socialMediaIcons: ['', [Validators.nullValidator]],
      toggleMsgCustomerTImezone: ['', [Validators.nullValidator]],
      QueueWaitTime: ['', [Validators.nullValidator]],
      QueuePositionMsg: ['', [Validators.nullValidator]],
      toggleSneakPeak: ['', [Validators.nullValidator]],
      toggleCookieRead: ['', [Validators.nullValidator]],
      toggleEmailTranscript: ['', [Validators.nullValidator]],
      toggleDownloadTranscript: [true, [Validators.nullValidator]],
      toggleEndConversation: [true, [Validators.nullValidator]],
      toggleBranding: ['', [Validators.nullValidator]],
      toggleUNFYDBranding: ['', [Validators.nullValidator]],
      CopyrightText: ['', [Validators.nullValidator]],
      toggleBottomBranding: ['', [Validators.nullValidator]],
      togglePluginBranding: ['', [Validators.nullValidator]],
      watermarkMessageWindowImg: ['', [Validators.nullValidator]],
      watermarkPrechatWindowImg: ['', [Validators.nullValidator]],
      toggleMarquee: ['', [Validators.nullValidator]],
      FACEBOOKSOCIAL: ['', [Validators.nullValidator]],
      facebookURL: ['', [Validators.nullValidator]],
      TWITTERSOCIAL: ['', [Validators.nullValidator]],
      twitterURL: ['', [Validators.nullValidator]],
      INSTAGRAMSOCIAL: ['', [Validators.nullValidator]],
      instagramURL: ['', [Validators.nullValidator]],
      toggleAutocompletion: ['', [Validators.nullValidator]],
      toggleBotAvatar: ['', [Validators.nullValidator]],
      toggleDisplayName: ['', [Validators.nullValidator]],
      DisplayName: ['', [Validators.nullValidator]],
      toggleTagline: ['', [Validators.nullValidator]],
      toggleFollowback: ['', [Validators.nullValidator]],
      toggleHumanHandover: ['', [Validators.nullValidator]],
      toggleBotTrigger: ['', [Validators.nullValidator]],
      toggleBotBasedURL: ['', [Validators.nullValidator]],
      toggleBOTBrowserDur: ['', [Validators.nullValidator]],
      toggleBOTClickedBanner: ['', [Validators.nullValidator]],
      toggleCoBrowse: ['', [Validators.nullValidator]],
      toggleVideoCall: ['', [Validators.nullValidator]],
      toggleVideoRecording: ['', [Validators.nullValidator]],
      toggleVideoCopyURL: ['', [Validators.nullValidator]],
      toggleVideoScreenshare: ['', [Validators.nullValidator]],
      toggleVideoCallVideo: ['', [Validators.nullValidator]],
      toggleVideoCallAudio: ['', [Validators.nullValidator]],
      toggleVoiceCall: ['', [Validators.nullValidator]],
      toggleCallControl: ['', [Validators.nullValidator]],
      muteUnmute: ['', [Validators.nullValidator]],
      ToggleAgentJoinNoti: ['', [Validators.nullValidator]],
      toggleNetNotification: ['', [Validators.nullValidator]],
      toggleVolumeConrol: ['', [Validators.nullValidator]],
      toggleVideoConversation: ['', [Validators.nullValidator]],
      toggleRingCustomerInitiate: ['', [Validators.nullValidator]],
      toggleDisconnect: ['', [Validators.nullValidator]],
      togglePauseVideo: ['', [Validators.nullValidator]],
      toggleMaximizeVideo: ['', [Validators.nullValidator]],
      toggleStartStopCobrowsing: ['', [Validators.nullValidator]],
      toggleAllowDisallowControlAgent: ['', [Validators.nullValidator]],
      toggleScreenshare: ['', [Validators.nullValidator]],
      toggleAvatar: ['', [Validators.nullValidator]],
      toggleWelcomeTitle: ['', [Validators.nullValidator]],
      WelcomeTitle: ['', [Validators.nullValidator]],
      toggleWelcomeMSG: ['', [Validators.nullValidator]],
      WelcomeMsg: ['', [Validators.nullValidator]],
      prechatformOnline: ['', [Validators.nullValidator]],
      prechatformOffline: ['', [Validators.nullValidator]],
      togglePrivacyPolicy: ['', [Validators.nullValidator]],
      fieldsMandatory: ['', [Validators.nullValidator]],
      toggleLeaveOfflineMSG: ['', [Validators.nullValidator]],
      LeaveOfflineMSG: ['', [Validators.nullValidator]],
      toggleCustFeedback: ['', [Validators.nullValidator]],

    })


  }

  resetfunc() {
    this.form.reset();
  }
  
  getLanguage() {
    this.requestObj = {
      data: {
        spname: "usp_unfyd_tenant",
        parameters: {
          flag: "GET_LANGUAGE_DATA",
          processid: this.userDetails.Processid
        }
      }
    }
    this.api.post('index', this.requestObj).subscribe(res => {

      if (res.code == 200) {
        this.language = res.results.data;
      }
    })
  }

  UploadChatIcon(event, max_width, max_height) {
    var file = event.target.files[0];
    var size = Math.round(file.size / 1024);
    var extension = file.type;
    const formData = new FormData();
    var filename = this.userDetails.Id + '_webchat_' + this.datepipe.transform(new Date(), 'ddMMyyhhmmss');
    formData.append(filename, file);

    if (size > 2000) {
      this.common.snackbar("File Size");

    } else if (extension !== 'image/jpeg' && extension !== 'image/jpg' && extension !== 'image/png' && extension !== 'image/gif') {
      this.common.snackbar("File Type");
    } else {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {
          const img_height = rs.currentTarget['height'];
          const img_width = rs.currentTarget['width'];

          if (img_height > max_height && img_width > max_width) {
            this.common.snackbar("FileReso");
          } else {
            this.loader = true;
            this.api.post('upload', formData).subscribe(res => {
              if (res.code == 200) {
                this.form.controls['chatIconUploaded'].patchValue(res.results.URL);
                this.loader = false;
              } else {
                this.loader = false;
              }
            }, error => {
              this.loader = false;
            });
          }
        };
      };
      reader.readAsDataURL(file);
    }
  }

  addCampaign(flag){
    let obj5 = {
      data: {
        spname: "savecampaigndetails",
        parameters: {
          "CampaignID": 1234567, 
          "CampaignName":"UNFYD", 
          "Description":"test",
          "CampaignScheduleType":1,
          "CampaignChannelID":1,
          "TargetAudienceType":"UNFYD",
          "StartDateTime":"2023-03-23", 
          "EndDateTime":"2024-03-23",
          "IsApprovalNeeded":1,
          "StatusID":1,
          "CreatedBy":"Admin",
          "CampaignCategory":"test",
          "ApprovalStatus":"Send For Approval"
        }
      }
    }
    this.api.dynamicDashboard('https://nipunuat.unfyd.com:3001/api/pitch/index', obj5).subscribe((res: any) => {
      if (res.code == 200) {
        this.loader = false;
        let a: any = [];
        var temp1 = []
        let obj

        this.campaginData = res.results.data;

        for (var i = 0; i < res.results.data.length; i++) {
          temp1.push({ [res.results.data[i].ConfigKey]: res.results.data[i].ConfigValue, Id: res.results.data[i].Id })
        }
        obj = temp1.reduce(function (acc, val) {
          return Object.assign(acc, val);
        }, {});
        
        this.config = res.results.data;
        this.form.patchValue(obj);
        console.log("k", obj);
        console.log("v", this.form.value);

      }
    })
  }


}
