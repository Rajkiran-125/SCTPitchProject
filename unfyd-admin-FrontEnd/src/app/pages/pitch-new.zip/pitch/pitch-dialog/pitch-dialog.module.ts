import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PitchDialogRoutingModule } from './pitch-dialog-routing.module';
import { PitchDialogComponent } from './pitch-dialog.component';


@NgModule({
  declarations: [
    PitchDialogComponent
  ],
  imports: [
    CommonModule,
    PitchDialogRoutingModule
  ]
})
export class PitchDialogModule { }
