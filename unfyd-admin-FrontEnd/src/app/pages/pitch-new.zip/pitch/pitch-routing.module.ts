import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path : 'campaign',data:{title:'Campaign'},loadChildren:()=>import('./campaign/campaign.module').then(mod=>mod.CampaignModule)},
  //{path : 'campaign',data:{title:'Campaign'},loadChildren:()=>import('./campaign/campaign.module').then(mod=>mod.CampaignModule)},
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PitchRoutingModule { }
