import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pitch',
  templateUrl: './pitch.component.html',
  styleUrls: ['./pitch.component.scss']
})
export class PitchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
