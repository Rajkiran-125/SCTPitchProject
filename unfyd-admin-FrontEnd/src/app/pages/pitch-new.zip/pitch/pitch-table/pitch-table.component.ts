import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pitch-table',
  templateUrl: './pitch-table.component.html',
  styleUrls: ['./pitch-table.component.scss']
})
export class PitchTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
