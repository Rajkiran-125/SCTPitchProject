import { Component, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/global/api.service';
import { AuthService } from 'src/app/global/auth.service';
import { CommonService } from 'src/app/global/common.service';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { PitchDialogComponent } from '../../pitch-dialog/pitch-dialog.component';
import { ExcelService } from 'src/app/global/excel.service';
import { CdkDragDrop, CdkDrag, CdkDropList, CdkDropListGroup, moveItemInArray, transferArrayItem,} from '@angular/cdk/drag-drop';
import { PitchCommonService } from 'src/app/global/pitch-common.service';
import { first, take } from 'rxjs/operators';
import { error, log } from 'console';
import { regex } from 'src/app/global/json-data';

@Component({
  selector: 'app-add-campaign',
  templateUrl: './add-campaign.component.html',
  styleUrls: ['./add-campaign.component.scss']
})
export class AddCampaignComponent implements OnInit, OnDestroy, OnChanges {
  
  formName: any;
  selectedTab: any;
  form: FormGroup;
  excelFileUpload: any = [];
  conditionForm: FormGroup;
  userDetails: any;
  requestObj: any;
  language: any;
  channel:any;
  botFlowList: any;
  submittedForm: boolean = false;
  loader: boolean = false;
  formData: any = null;
  path: any;
  channelSRCID: any;
  productId: any;
  TemplateData: any = [];
  sampleExcelData: any = [{
    "Sr.No": "",
    "Campaign Name": "",
    "Campaign Type": "",
    "Channel": ""
  }];
  sendEmailDur:any = [];
  channelSourceAvailable: boolean = false;
  selectedStructure = [];
  templateID: any;
  template: any = [];
  subscription: Subscription[] = [];
  SampleCampaignExcel: any = [];
  Conditonsdata: any = [];
  templateVisible: boolean = false;
  cardTemplate: any;
  campaginData: any;
  config: any;
  time = { hour: 0, minute: 0, second: 0 }
  ChannelSource: any = [];
  ChannelSource1: any = [];
  Channel: any;
  Sender: any;
  temp: any;
  showBtn:boolean=false;
  disabledBtn:boolean = false;
  campaignType: any[];
  campaignTime: any[] = [
    {hour:0, minute:0,second:0}
  ];
  
 audienceFieldListNameArray=[];
  configdata: any;
  showThrottling: any = false;
  templateData: any = {};
  templateData1: any = {};
  fileData: any;
  ObjectKeys = Object.keys
  conditionIndex :number
  actionIndex :number
  languageSelected :string
  excelFileName: any;
  //campaignTypeSelected: any;
  dataTypes=[{Id:1, type:"Int"},{Id:2, type:"String"}];
  // nullableValues=[{Id:1, type:"true"},{Id:3, type:"false"}];
  yesNoBtnValue:boolean=false;
  isTableExist:boolean=false;
  sub$: Subscription;
  isNullableBoolean:any = false;
  campaignId:any;
  AudienceListName:any;
  StructureList:any;
  channelId:any;
  errorMsg:boolean=false;
  AudienceListNameSave:boolean=false;
  actionableId:any;
  channelSource1ChannelId:any;
  structureListArr=[];
  defaultDate:Date;
  selectedTypeOption:number=1;
  structureListId:any;
  patchfieldMapping : any;

  constructor(
    private router:Router,
    private api: ApiService,
    private formBuilder: FormBuilder,
    public pitchCommon : PitchCommonService,
    public common: CommonService,
    private excelService: ExcelService,
    private auth: AuthService,
    public datepipe: DatePipe,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog) {this.defaultDate = new Date(); }
  

  ngOnChanges(){
    // this.addAudienceTableList();
  }

  ngOnInit(): void {
    // console.log(this.Conditonsdata);
    // console.log(this.form.get('AudienceListNameArray'));
    
    this.userDetails = this.auth.getUser();
    this.path = this.activatedRoute.snapshot.paramMap.get('id');
    this.channelSRCID = this.activatedRoute.snapshot.paramMap.get('uniqueid');
    this.productId = this.activatedRoute.snapshot.paramMap.get('productId');
    
    // console.log(this.path);
    // console.log(this.channelSRCID);
    // console.log(this.productId);
    
    // this.type = this.activatedRoute.snapshot.paramMap.get('type');
    this.getLanguage();
    this.getChannel();
    this.getCampaignType();
    this.getdurationlist();
    this.getStructureList();
    
    
    // this.callDialog()
    
    this.form = this.formBuilder.group({

      CampaignName: ['', [Validators.required]],
      CampaignDesc: ['', [Validators.required]],
      CampaignTemplate: ['', [Validators.required]],
      CampaignType: ['', [Validators.required]],
      ChannelList: ['Whatsapp', [Validators.required]],
      sendEmailDur: ['Mins', [Validators.required]],
      campaignTypeSelected: ['', [Validators.required]],
      ChannelSrc: ['', [Validators.required]],
      toggleMultilingual: ['', [Validators.required]],
      targetAudienceList: ['ImportNew', [Validators.required]],
      // AudienceListNameArray: this.formBuilder.array([]),
      headerType: ['', [Validators.required]],
      AudienceListName: ['', [Validators.required,Validators.pattern(regex.alphaNumericWithoutSpace)]],
      structureList:['', [Validators.required]],
      CampaignStartDate: ['', [Validators.required]],
      CampaignEndDate: ['', [Validators.required]],
      isThrottlingEnabled:[''],
      campaignSendLimit: ['', [Validators.required]],
      campaignSendFrequency: ['', [Validators.required]],
      //campaignSendDuration: ['Mins', [Validators.required]],
      pollingTimer: [{ hour: 0, minute: 0, second: 0 }, [Validators.required]],
      pollingUrlBody: ['', [Validators.required]],
      pollingHeaders : this.formBuilder.array([this.createPollingHeaders()]),
      CampaignTemplateAction: this.formBuilder.array([this.addTemplateAction()]),
      // pollingHeaderKey: ['', [Validators.required]],
      // pollingHeaderValue: ['', [Validators.required]],
      condition: this.formBuilder.array([this.addCondition()]),
      
      // getAndOrCondition: ['', [Validators.required]],
      // languageSelected: [[], Validators.nullValidator],
      audienceListField: ['', [Validators.required]],
      fieldMapping:this.formBuilder.array([this.addFMCondition()])
    })
  

    // setTimeout(() => {
    //   console.log(this.form)
    // }, 5000);

    this.common.setMasterConfig();
    this.subscription.push(
      this.common.getMasterConfig$.subscribe((data) => {
        // debugger;
        // console.log(data);
        
        if (Object.keys(data).length > 0) {
          this.SampleCampaignExcel = JSON.parse(data["SampleCampaignExcel"]);
          this.Conditonsdata = JSON.parse(data["Conditionscampaign"]);
          // console.log(this.Conditonsdata);
          
          // console.log(this.SampleCampaignExcel);
          if(this.SampleCampaignExcel.length > 0){
            let obj = {}
            this.SampleCampaignExcel.forEach(el => {  
              Object.assign(obj, {[el.Key]: ''});
            });
            this.sampleExcelData = [obj];
             //console.log("helloooooo:", this.sampleExcelData);            
          }
          
          if(this.Conditonsdata.length > 0){
            let obj123 = {}
            this.Conditonsdata.forEach(el => {  
              Object.assign(obj123, {[el.Key]: ''});
            });
            this.Conditonsdata = [obj123];
            // console.log(this.Conditonsdata);
          }
        }
      })
    )
  }

  


 

  // getIsNullable(e:any){
  //   // console.log(e.checked);
  //   if(e.checked){
  //     return this.isNullableBoolean = true;
  //   }else{
  //     return this.isNullableBoolean = false;
  //   }
  // }

  // saveAudienceTableList(){  
  //   this.loader = true;
  //     let addFormArray = (this.form.get('AudienceListNameArray') as FormArray).value;
  //     // console.log(addFormArray);
  //     this.audienceFieldListNameArray=[]
  //       addFormArray.forEach((element)=>{
  //         // console.log(element);
  //          let obj =
  //           {
  //             Columnname: element.columnName,
  //             Datatype: element.dataType,
  //              maxlength: element.maxLength,
  //              isnullable: element.isNullable == true ? 1 : 0
  //            }  
  //            this.audienceFieldListNameArray.push(obj);  
  //            //console.log(this.audienceFieldListNameArray); 
  //            var Obj1 = {
  //             data: {
  //               spname: "usp_unfyd_create_update_table",
  //               parameters: {
  //                 tablename : this.form.get('AudienceListName').value,
  //                 Columnname : obj.Columnname,
  //                 Datatype : obj.Datatype,
  //                 Maxlength:obj.maxlength,
  //                 IsNull : obj.isnullable,
  //                 "Flag":"CREATE"
  //               }
  //             }
  //           }   
  //           this.api.post('pitch/index', Obj1).subscribe((res)=>{
  //                 //  console.log(res); 
  //                  if(res.code == 200){
  //                   this.loader = false;
  //                     this.common.snackbar("Save Successfully");
  //                   this.disabledBtn = true;
  //                   this.AudienceListNameSave=true;
  //                  }  
  //                 //  console.log(this.audienceFieldListNameArray);   
  //             })
  //          });  
  //     }

  
  // createAudienceTable(){
  //   var Obj1 = {
  //     data: {
  //       spname: "usp_unfyd_create_update_table",
  //       parameters: {
  //         tablename : this.form.get('AudienceListName').value,
  //         Columnname : "",
  //         Datatype : "",
  //         Maxlength:"",
  //         IsNull : "",
  //         "Flag":"CREATE"
  //       }
  //     }
  //   }
  //   this.api.post('pitch/index', Obj1).subscribe((res)=>{
  //         if(res){
  //            if(res.message == "Success"){
  //                  this.saveAudienceTableList();
  //            }
  //         }
  //    })
  // }

  // checkIfTableExistOrNot(){
  //   this.loader = true;
  //   let name = this.form.get('AudienceListName').value;
  //   var obj2 = {
  //     data: {
  //       spname: "CheckIfTableExists",
  //       parameters: {
  //         TableName: name
  //       }
  //     }
  //   }  
  //   this.api.post('pitch/index', obj2).subscribe((res)=>{
  //     if(res){
  //       if(res.code == 200){
  //         this.loader = false;
  //           if(res.results.data[0].Result == "Exist"){
  //               this.isTableExist = true;                  
  //           }
  //           else{
  //              this.isTableExist = false;
  //           }
  //            if(this.isTableExist == true){
  //                this.okDialog();
  //                 return false;
  //              }else{
  //               // this.createAudienceTable();
  //                 if(this.getAudienceListNames().length == 0){
  //                 this.getAudienceListNames().push(this.createAudienceListName()); 
  //                  }   
  //               } 
  //               this.showBtn = true;      
  //          }
  //       }
  //   })  
  // }

  // getAudienceListNames():FormArray{
  //   return this.form.get('AudienceListNameArray') as FormArray;
  // }

  // addAudienceColumn(){
  //   this.disabledBtn = false;
    
  //   let lastItem = this.getAudienceListNames().controls.length-1;
  //   let status = this.getAudienceListNames()?.controls[lastItem]['status'];
  //   //console.log(lastItem);
  //   //console.log(status);
  //    if(status == 'VALID'){
  //     // this.errorMsg = false;
  //       this.getAudienceListNames().push(this.createAudienceListName());
  //     } else {
  //     //  this.errorMsg = true;
  //     this.common.snackbar("Fill Audience List Name columns first")
  //     }
  //   // console.log(this.form.controls['AudienceListNameArray']['controls'][i]['status']);
  // }

  // removeAudienceListName(i){
  //   this.getAudienceListNames().removeAt(i);
  //   if(this.getAudienceListNames().length == 0){
  //     this.showBtn = false;
  //   }
  // }

  // createAudienceListName():FormGroup {
  //   return this.formBuilder.group({
  //     columnName: ['', Validators.required],
  //     dataType: ['', Validators.required],
  //     maxLength: ['', Validators.required],
  //     isNullable: [''],
  //   });
  // }
 
  // okDialog() {
  //  const dialogRef =  this.dialog.open(PitchDialogComponent, {
  //     data:{
  //      type : "confirmation"
  //     },
  //     disableClose: true,
  //     height: '25%',
  //     width: '30%'
  //   });
  // }







  
  //PolingHeaders FormArray
  getPollingHeaders():FormArray{
    return this.form.get('pollingHeaders') as FormArray;
  }

  createPollingHeaders():FormGroup {
    return this.formBuilder.group({
      pollingHeaderKey: ['',[Validators.required]],
      pollingHeaderValue: ['',[Validators.required]],
    });
  }

  addPollingHeaders(){
     this.getPollingHeaders().push(this.createPollingHeaders());
  }

  removePollingHeaders(i){
    this.getPollingHeaders().removeAt(i);
  }


  getActionTemplate(): FormArray {
    return this.form.get('CampaignTemplateAction')['controls'] as FormArray;
  }
  createActionTemplate(): FormArray {
    // return this.formBuilder.group({
    //   action: this.formBuilder.array([this.addAction()])
    // })
    return this.formBuilder.array([this.addAction(), this.addAction()])
  }

  addTemplateAction(): FormGroup {
    return this.formBuilder.group({
      channel: ['', Validators.required],
      channelSource: ['', Validators.nullValidator],
      languageSelected: [[], Validators.nullValidator],
      hsmSelected: [{}, Validators.nullValidator],
      fieldMapping: this.formBuilder.group({})
      // fieldMapping: new FormGroup({})
      // [this.formBuilder.group({}), Validators.nullValidator],
    })
  }
  removeActionTemplate(i) {
    this.getActionTemplate().removeAt(i);
  }


  getAndOrCondition(value) {
    //console.log('Hello :', value);
  }
  selectLan(value,i,j) {
    console.log('Language :', value);
    if(value.length > 0){
      if(Object.keys(this.form.value.condition[i].action[j].hsmSelected).length > 0){
        console.log(Object.keys(this.form.value.condition[i].action[j].hsmSelected));
        // delete value which is not in language
        let valuesInHSMSelected = Object.keys(this.form.value.condition[i].action[j].hsmSelected).filter(x => !value.includes(x))
        console.log(valuesInHSMSelected)
        let obj1 = this.form.value.condition[i].action[j].hsmSelected
        if(valuesInHSMSelected.length > 0){
          valuesInHSMSelected.forEach(el => {
            delete obj1[el]
            // this.getFMAction(i)['controls']['action']['controls'][j]['controls']['hsmSelected'].removeControl(el)
            this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected'].removeControl(el)
          })
          this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(obj1)
        }
                  
        //add value 
        let valuesInHSMSelected1 = value.filter(x => !Object.keys(this.form.value.condition[i].action[j].hsmSelected).includes(x))
        console.log(valuesInHSMSelected1)
        let obj2 = this.form.value.condition[i].action[j].hsmSelected
        if(valuesInHSMSelected1.length > 0){
          valuesInHSMSelected1.forEach(el => {
            Object.assign(obj2,{[el]:''})
            this.form.controls['fieldMapping']['controls'][i]['controls']['action']?.['controls']?.[j]?.['controls']?.['hsmSelected']?.addControl(el,this.formBuilder.array([]))
          })
          this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(obj2)
        }
      }else{
        let obj = {}
        value.forEach(element => {
          Object.assign(obj,{[element]:''})
          this.form.controls['fieldMapping']['controls'][i]['controls']['action']?.['controls']?.[j]?.['controls']?.['hsmSelected']?.addControl(element,this.formBuilder.array([]))
        });
        this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(obj);        
      }      
    } else{
      let obj = Object.keys(this.form.value.fieldMapping[i].action[j].hsmSelected)
      if(obj.length > 0){
        this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected'].removeControl(obj)
      }
      this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue({});  
    }
    console.log(this.form);
    console.log(this.form.controls['fieldMapping']['controls'][i]['controls']['action']?.['controls']?.[j]?.['controls']?.['hsmSelected'])
    

  }
  selectLan1(value,i) {
    console.log('Language :', value);
    if(value.length > 0){
      if(Object.keys(this.form.value.templateAction[i].hsmSelected).length > 0){
        console.log(Object.keys(this.form.value.templateAction[i].hsmSelected));
        // delete value which is not in language
        let valuesInHSMSelected = Object.keys(this.form.value.templateAction[i].hsmSelected).filter(x => !value.includes(x))
        console.log(valuesInHSMSelected)
        let obj1 = this.form.value.templateAction[i].hsmSelected
        if(valuesInHSMSelected.length > 0){
          valuesInHSMSelected.forEach(el => {
            delete obj1[el]
            // this.getFMAction(i)['controls']['action']['controls'][j]['controls']['hsmSelected'].removeControl(el)
            this.form.controls['fieldMapping']['controls'][i]['controls']['hsmSelected'].removeControl(el)
          })
          this.getAction(i)['controls']['hsmSelected'].patchValue(obj1)
        }
                  
        //add value 
        let valuesInHSMSelected1 = value.filter(x => !Object.keys(this.form.value.templateAction[i].hsmSelected).includes(x))
        console.log(valuesInHSMSelected1)
        let obj2 = this.form.value.templateAction[i].hsmSelected
        if(valuesInHSMSelected1.length > 0){
          valuesInHSMSelected1.forEach(el => {
            Object.assign(obj2,{[el]:''})
            this.form.controls['fieldMapping']['controls'][i]['controls']['hsmSelected']?.addControl(el,this.formBuilder.array([]))
          })
          this.getAction(i)['controls']['hsmSelected'].patchValue(obj2)
        }
      }else{
        let obj = {}
        value.forEach(element => {
          Object.assign(obj,{[element]:''})
          this.form.controls['fieldMapping']['controls'][i]['controls']['hsmSelected']?.addControl(element,this.formBuilder.array([]))
        });
        this.getAction(i)['controls']['hsmSelected'].patchValue(obj);        
      }      
    } else{
      let obj = Object.keys(this.form.value.fieldMapping[i].hsmSelected)
      if(obj.length > 0){
        this.form.controls['fieldMapping']['controls'][i]['controls']['hsmSelected'].removeControl(obj)
      }
      this.getAction(i)['controls']['hsmSelected'].patchValue({});  
    }
    console.log(this.form);
    console.log(this.form.controls['fieldMapping']['controls'][i]['controls']['hsmSelected']);
  }

 

  addMoreCondition() {
    this.f1.push(this.addCondition())
    this.f2.push(this.addFMCondition())
  }

  get f1() { return this.form.get('condition') as FormArray }
  get f2() { return this.form.get('fieldMapping') as FormArray }
  getCondition(): FormArray {
    return this.form.get('condition') as FormArray;
  }
  getSubCondition(index): FormArray {
    return this.getCondition().at(index).get('subcondition') as FormArray;
  }
  getAction(index): FormArray {
    return this.getCondition().at(index).get('action') as FormArray;
  }
  getFMCondition(): FormArray {
    return this.form.get('fieldMapping') as FormArray;
  }
  getFMAction(index): FormArray {
    return this.getFMCondition().at(index).get('hsmSelected') as FormArray;
  }
  getfieldMapping(){
    return this.form.get('fieldMapping') as FormArray;
  }
  getfieldMappingAction(index): FormArray {
    // console.log(this.getFMCondition().at(index));
    return this.getFMCondition().at(index).get('action') as FormArray;
  }
  getfieldMappingHsmSelected(i,j): FormGroup {
    //console.log("hsmSelected:",this.getfieldMappingAction(i).at(j).get('hsmSelected'));
    return this.getfieldMappingAction(i).at(j).get('hsmSelected') as FormGroup;
  }
  getfieldMappingLanguage(i,j,language): FormArray {
    //console.log(language,":",this.getfieldMappingAction(i).at(j).get('hsmSelected').get(language));
    return this.getfieldMappingAction(i).at(j).get('hsmSelected').get(language) as FormArray;
  }
  getFMField(): FormArray {
    // console.log(this.form.controls['fieldMapping']['controls'][this.conditionIndex]['controls']['action']['controls'][this.actionIndex]['controls']['hsmSelected']['controls'][this.languageSelected]['controls']);
    
    return this.form.controls['fieldMapping']['controls'][this.conditionIndex]['controls']['action']['controls'][this.actionIndex]['controls']['hsmSelected']['controls'][this.languageSelected]['controls'] as FormArray;
    // return this.getFMAction(this.conditionIndex).at(this.actionIndex).get('hsmSelected').get(this.languageSelected) as FormArray
  }
  
  createFMAction(index){
    this.getFMAction(index).push(this.addFMAction())
  }
   addCondition(): FormGroup {
    return this.formBuilder.group({
      conditionName: ['', Validators.required],
      // Channel: ['', Validators.required],
      // ChannelSource: ['', Validators.nullValidator],
      subcondition: this.formBuilder.array([this.addSubCondition()]),
      action: this.formBuilder.array([this.addAction()])
    })
  }
  addFMCondition(): FormGroup {
    return this.formBuilder.group({
      action: this.formBuilder.array([this.addFMAction()])
    })
  }

  addFMAction(): FormGroup {
    return this.formBuilder.group({
      hsmSelected: this.formBuilder.group({}),
    })
  }

  addFMField(): FormGroup {
    return this.formBuilder.group({
      templateField: [''],
      attributeMappingField: ['', Validators.required],
    })
  }


  addfieldMappingAction1Obj(element) {
    this.patchfieldMapping = element ? element : null;
  }
  addFieldMappingObj(i,j,language){
    this.form.controls['fieldMapping']['controls'][i]['controls']['action']?.['controls']?.[j]?.['controls']?.['hsmSelected']?.['controls']?.[language]?.push(this.addFMField())
  }
  patchFieldMappingObj(i,j,language,index,templateField){
    this.form.controls['fieldMapping']['controls'][i]['controls']['action']?.['controls']?.[j]?.['controls']?.['hsmSelected']?.['controls']?.[language]?.['controls']?.[index]?.['controls']?.['templateField']?.patchValue(templateField)
  }


  addAction(): FormGroup {
    return this.formBuilder.group({
      channel: ['', Validators.required],
      channelSource: ['', Validators.nullValidator],
      languageSelected: [[], Validators.nullValidator],
      hsmSelected: [{}, Validators.nullValidator],
    })
  }

  addSubCondition(): FormGroup {
    return this.formBuilder.group({
      field: ['', Validators.required],
      subcondition: ['', Validators.nullValidator],
      conditionvalue: ['', Validators.nullValidator],
      getAndOrCondition: ['', Validators.nullValidator],
    })
  }

  campaignConditions(): FormArray {
    return this.conditionForm.get('conditions') as FormArray;
  }

  newConditon(): FormGroup {
    return this.formBuilder.group({
      ConditonNameSelected: ['', [Validators.required]],
      SelectedField: ['', [Validators.required]],
      SelectedCondition: ['', [Validators.required]],
      SelectedConditionValue: ['', [Validators.required]],
      SelectedFieldOne: ['', [Validators.required]],
      SelectedConditionOne: ['', [Validators.required]],
      SelectedConditionValueOne: ['', [Validators.required]],
      subcondition: this.formBuilder.array([]),
      action: [''],
      
    });
  }


  newAction(): FormGroup {
    return this.formBuilder.group({
      SelectedChannel: ['', [Validators.required]],
      SelectedChannelSource: ['', [Validators.required]],
      languageSelected: ['', [Validators.required]]
    });
  }


  createAction(index){
    //console.log(index);
    
    this.getAction(index).push(this.addAction());
    
    this.getFMAction(index)?.push(this.addFMAction());
  }
  createSubCondition(index){
    this.getSubCondition(index).push(this.addSubCondition());
  }
  
  removeCondition(conditionIndex){
    this.getCondition().removeAt(conditionIndex);
  }
  removeAction(conditionIndex,actionIndex){
    this.getAction(conditionIndex).removeAt(actionIndex);
  }

  removeSubCondition(conditionIndex,actionIndex){
    this.getSubCondition(conditionIndex).removeAt(actionIndex)
  }

  

  downloadSampleExcel(){
   // console.log(this.sampleExcelData);
   // console.log(this.audienceFieldListNameArray);
    // this.audienceFieldListNameArray = [
    //   {Columnname: "FirstName",
    //   Datatype: "String",
    //   isnullable: 0,
    //   maxlength: "2"},
    //   {Columnname: "LastName",
    //   Datatype: "String",
    //   isnullable: 0,
    //   maxlength: "23"}
    //   ];
      //console.log(this.audienceFieldListNameArray);
       
      let val = this.form.get('structureList').value;
      console.log(val);
      let findObj = this.structureListArr.find((i)=>{
        return i.Id == val;
      })
      console.log(findObj);
      
    let downloadSampleExcelColumns = [];
    let x = JSON.parse(findObj.StructureJson);
    console.log(x);
    
    x.forEach((element)=>{
      console.log(element);
       let obj = {};
      obj[element.FieldName] = '';
      downloadSampleExcelColumns.push(obj);
    })
    
     console.log(downloadSampleExcelColumns);
    
    
    this.excelService.exportExcel(downloadSampleExcelColumns, ('Pitch_Sample_Format').toUpperCase());

    // let downloadSampleExcelColumns = [];
    // this.audienceFieldListNameArray.forEach((element)=>{
    //    let obj = {};
    //   obj[element.Columnname] = '';
    //   downloadSampleExcelColumns.push(obj);
    // })
    
  }


  resetfunc() {
    this.form.reset();
  }

  getStructureList(){
   var Obj = {
      "data": {
          "spname": "usp_unfyd_geud_structurelist",
          "parameters": {
              "flag": "GET"
          }
      }
   }
    this.api.post('pitch/index', Obj).subscribe((res: any) => {
      if (res.code == 200) {
        this.structureListArr = res.results.data;
        // console.log("StructureList", this.structureListArr);
        // console.log("Hello", this.form.controls);
        if(this.structureListArr.length > 0) this.form.controls.structureList.patchValue(this.structureListArr[0].Id); 
      }
    });
  }

  getChannel() {
    this.requestObj = {
      data: {
        spname: "usp_unfyd_getdropdowndetails",
        parameters: {
          flag: "CHANNEL",
          processid: this.userDetails.Processid,
        }
      }
    };
    this.api.post('index', this.requestObj).subscribe((res: any) => {
      if (res.code == 200) {
        this.Channel = res.results.data;
        //console.log(this.Channel); 
      }
    });
  }

  getSenderData(channel, sourceId) {
    this.loader = true;
    let channelData = this.Channel.filter(obj => {
      if (obj.ChannelId === channel) {
        return obj;
      }
    });
    if (channelData[0].ChannelName === 'WhatsApp') {
      this.requestObj = {
        data: {
          spname: "USP_UNFYD_NOTIFICATION",
          parameters: {
            flag: 'GET_CONTACT_NUMBER',
            CHANNELSOURCE: sourceId
          }
        }
      };
      this.api.post('index', this.requestObj).subscribe(res => {
        if (res.code == 200) {
          res.results.data.forEach(element => {
            this.Sender.push({ Key: element.WhatsAppNumber, Value: element.WhatsAppNumber })
          });
          this.loader = false;
        } else this.loader = false;
      });
    } else this.loader = false;
  }

  getFields(event) {
    this.TemplateData = [];
    this.template = [];
    this.templateVisible = false;
    this.cardTemplate = [];
    this.form.get('ChannelSource').reset();
    this.form.get('Template').reset();
    this.form.updateValueAndValidity();
    // let channel = this.Channel.filter(obj => {
    //   if (obj.ChannelId === event) {
    //     return obj;
    //   }
    // });
    // if (channel[0].ChannelName === 'Email') {
    //   this.emailChannel = true;
    //   this.whatsAppChannel = false;
    // } else if (channel[0].ChannelName === 'WhatsApp') {
    //   this.whatsAppChannel = true;
    //   this.emailChannel = false;
    // } else {
    //   this.emailChannel = false;
    //   this.whatsAppChannel = false;
    // }
  }
  getLanguage() {
    this.requestObj = {
      data: {
        spname: "usp_unfyd_tenant",
        parameters: {
          flag: "GET_LANGUAGE_DATA",
          processid: this.userDetails.Processid
        }
      }
    }
    this.api.post('index', this.requestObj).subscribe(res => {
      if (res.code == 200) {
        this.language = res.results.data;
        // console.log(this.language);
      }
    })
  }

  getCampaignType(){
   var requestObj  = {
      data: {
        spname: "USP_UNFYD_GetDropdownData",
        parameters: {
          "Flag":"CAMPAIGNSCHEDULETYPES"
        }
      }
    };
    
    this.api.post('pitch/index', requestObj).subscribe((res: any) => {
      if (res.code == 200) {
        this.campaignType = res.results.data;
       // console.log(this.campaignType);    
      }
    });
  }

  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(
        event.previousContainer.data,
        event.container.data,
        event.previousIndex,
        event.currentIndex,
      );
    }
  }

  UploadChatIcon(event, max_width, max_height) {
    var file = event.target.files[0];
    var size = Math.round(file.size / 1024);
    var extension = file.type;
    const formData = new FormData();
    var filename = this.userDetails.Id + '_webchat_' + this.datepipe.transform(new Date(), 'ddMMyyhhmmss');
    formData.append(filename, file);

    if (size > 2000) {
      this.common.snackbar("File Size");

    } else if (extension !== 'image/jpeg' && extension !== 'image/jpg' && extension !== 'image/png' && extension !== 'image/gif') {
      this.common.snackbar("File Type");
    } else {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {
          const img_height = rs.currentTarget['height'];
          const img_width = rs.currentTarget['width'];

          if (img_height > max_height && img_width > max_width) {
            this.common.snackbar("FileReso");
          } else {
            this.loader = true;
            this.api.post('upload', formData).subscribe(res => {
              if (res.code == 200) {
                this.form.controls['chatIconUploaded'].patchValue(res.results.URL);
                this.loader = false;
              } else {
                this.loader = false;
              }
            }, error => {
              this.loader = false;
            });
          }
        };
      };
      reader.readAsDataURL(file);
    }
  }

  
  UploadCampaignExcel(event) {
  
      //console.log(event);
    
      var file = event.target.files[0];
      // var size = Math.round(file.size / 1024);
      var extension = file.type;
      // const formData = new FormData();
      var UI_FileName = file.name;
      var filename = this.userDetails.Id + '_Campaign_' + this.datepipe.transform(new Date(), 'ddMMyyhhmmss');
      // formData.append(filename, file);
      //console.log("there", extension);
      
      // if (size > 5000) {
      //   this.common.snackbar("File Size");
  
  
      // } else if (extension !== 'image/jpeg' && extension !== 'image/jpg' && extension !== 'image/png' && extension !== 'image/gif') {
      //   this.common.snackbar("File Type");
      // } else {
      //   const reader = new FileReader();
      //   reader.onload = (e: any) => {
      //     this.excelService.importExcel(event)        
      //   };
      //   reader.readAsDataURL(file);
      // }
  
      let filetype = event.target.files[0].type
      if (filetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
        setTimeout(() =>{
          this.excelService.importExcel(event)
          setTimeout(() =>{
            this.temp = JSON.parse(JSON.stringify(this.excelService.getJson()));
            this.excelFileUpload.push({UI_File:UI_FileName,name:filename,status:false,file:file,data:this.temp})
            
            this.uploadExcelFiles();
            
            //console.log('test', this.excelFileUpload);
          },1000)
        },1000);
        // setTimeout(() => {
          // if(this.excelService.getJson()){   
                // this.temp = JSON.parse(JSON.stringify(this.excelService.getJson()));
                // this.excelFileUpload.push({name:filename,status:false,file:file,data:this.temp})
                // console.log('test', this.excelFileUpload);
            // }
        // });
        //console.log("suyog", this.temp);
      }
      else {
        this.common.snackbar('Please Upload ".xlsx" format file', 'error');
        return
      }
    
  }

  uploadExcelFiles(){
    // var file = event.target.files;

    if(this.excelFileUpload.length > 0){
      this.excelFileUpload.forEach(element => {
       // console.log(element.file.type);
        //console.log(element.status);
        
        if (!element.status && element.file.type == 
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
          var formData = new FormData();
        //  const formData = {};
          
          this.AudienceListName = this.form.get('AudienceListName').value;
          this.StructureList = this.form.get('structureList').value;
          this.excelFileName = element.name;
          var filename = element.name;
          // formData[filename] = element.file;
          // formData['AudienceListName'] = this.AudienceListName;
        
          formData.append(filename, element.file);
          formData.append('AudienceListName', this.AudienceListName);
          // for (var key of formData1.entries()) {
          //   console.log(key[0] + ', ' + key[1]);
          //   }
          // console.log(JSON.stringify(formData));
          formData.append('StructureId', this.StructureList);
          
          element.status = 'uploading'
          console.log(formData);
           //const formDataArray = [...formData];

          // Log the array to the console
          //console.log(formDataArray);
          
          this.loader = true;
          
          this.api.post('pitch/upload', formData).subscribe((res) => {
            console.log("nnnnn", res);
            
              if (res.code == 200) {
                element.status = true;
                this.showThrottling = true;
                this.loader = false;
                this.common.snackbar("Excel Uploaded Successfully","success");  
                
              }
            }, (error) => {
              this.loader = false;
              this.common.snackbar(error.error.message,'error');
              this.formData = '';
          });
      //)
        }
      });
  
    } else if(this.excelFileUpload.length == 0){
      this.common.snackbar('Please choose at least one excel file', 'error');
    }
  }

  removeExcelFileUpload(i){
    this.excelFileUpload.splice(i, 1);
  }

  deleteExcelRow(i) {
    // const index: number = this.excelFileUpload.indexOf(i);
    // this.excelFileUpload.splice(index, i);
    this.excelFileUpload.splice(i, 1);
  }


getChannelSource(i,j,ChannelId) {
    this.channelId = this.form.value.condition[i].action[j].channel;
    //console.log(this.channelId);
    
    this.loader = true;
    this.requestObj = {
      data: {
        spname: "USP_RULEMASTER_PROC",
        parameters: {
          flag: "CHANNELSOURCE",
          channelid : this.form.value.condition[i].action[j].channel,
          processid: this.userDetails.Processid
        }
      }
    };
    // console.log("Hey", this.requestObj);
    // console.log("1", i);
    // console.log("2", j);
    //console.log("3", ChannelId);
    
    this.api.post('index', this.requestObj).subscribe((res: any) => {
      if (res.code == 200) {        
        this.ChannelSource = res.results.data;
        //console.log("vishal", res);
        this.loader = false;
      } else this.loader = false;
    });
  }
getChannelSource1(ChannelId) {
  this.channelSource1ChannelId = ChannelId;
    this.loader = true;
    this.requestObj = {
      data: {
        spname: "USP_RULEMASTER_PROC",
        parameters: {
          flag: "CHANNELSOURCE",
          channelid: ChannelId,
          processid: this.userDetails.Processid
        }
      }
    };
    // console.log("Hey", this.requestObj);
    // console.log("1", i);
    // console.log("2", j);
    //console.log("3", ChannelId);

    this.api.post('index', this.requestObj).subscribe((res: any) => {
      if (res.code == 200) {
        this.ChannelSource1 = res.results.data;
        //console.log("vishal", res);
        this.loader = false;
      } else this.loader = false;
    });
  }

  getTemplate(i,j,event) {
  
     let obj = {
     data: {      
      spname: "usp_unfyd_hsm_template",      
      parameters: {      
       FLAG: "GET_HSM",
       PROCESSID: this.userDetails.Processid,
       CHANNELID: this.form.value.condition[i].action[j].channel,
       UNIQUEID: this.form.value.condition[i].action[j].channelSource
       }
     }
     
    };
    // console.log("chiron", obj);

    this.api.post('index', obj).subscribe((res: any) => {
      if (res.code == 200) {
       // console.log("poonam",res)
        // this.templateData[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource] = res.results.data;
        if(res.results.data.length > 0){
          res.results.data.forEach(element => {
            // if(Object.keys(this.templateData[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource]).includes(element.Actionable)){
              if(!this.templateData.hasOwnProperty((this.form.value.condition[i].action[j].channel).toString())){
                console.log(!this.templateData.hasOwnProperty((this.form.value.condition[i].action[j].channel).toString()));
                
                Object.assign(this.templateData,{[(this.form.value.condition[i].action[j].channel).toString()]:{}})
              }
              if(!this.templateData[(this.form.value.condition[i].action[j].channel).toString()].hasOwnProperty((this.form.value.condition[i].action[j].channelSource).toString())){
                console.log(!this.templateData[(this.form.value.condition[i].action[j].channel).toString()].hasOwnProperty((this.form.value.condition[i].action[j].channelSource).toString()));
                Object.assign(this.templateData[(this.form.value.condition[i].action[j].channel).toString()],{[(this.form.value.condition[i].action[j].channelSource).toString()]:{}})
              }
              if(!this.templateData[(this.form.value.condition[i].action[j].channel).toString()][(this.form.value.condition[i].action[j].channelSource).toString()].hasOwnProperty((element.Actionable).toString())){
                console.log(!this.templateData[(this.form.value.condition[i].action[j].channel).toString()][(this.form.value.condition[i].action[j].channelSource).toString()].hasOwnProperty((element.Actionable).toString()));                
                Object.assign(this.templateData[(this.form.value.condition[i].action[j].channel).toString()][(this.form.value.condition[i].action[j].channelSource).toString()],{[(element.Actionable).toString()]:{}})
              }
              
              this.templateData[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource][element.Actionable] = element
            // }
          });

        }
        // console.log("Bugatti", this.templateData);
        this.loader = false;
      } else this.loader = false;
    });
    
  }

  getTemplate1(i, event) {

    let obj = {
      data: {
        spname: "usp_unfyd_hsm_template",
        parameters: {
          FLAG: "GET_HSM",
          PROCESSID: this.userDetails.Processid,
          CHANNELID: this.form.value.CampaignTemplateAction[i].channel,
          UNIQUEID: this.form.value.CampaignTemplateAction[i].channelSource
        }
      }

    };
    // console.log("chiron", obj);

    this.api.post('index', obj).subscribe((res: any) => {
      if (res.code == 200) {
        // console.log("poonam",res)
        // this.templateData1[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource] = res.results.data;
        if (res.results.data.length > 0) {
          res.results.data.forEach(element => {
            // if(Object.keys(this.templateData1[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource]).includes(element.Actionable)){
            if (!this.templateData1.hasOwnProperty((this.form.value.CampaignTemplateAction[i].channel).toString())) {
              console.log(!this.templateData1.hasOwnProperty((this.form.value.CampaignTemplateAction[i].channel).toString()));

              Object.assign(this.templateData1, { [(this.form.value.CampaignTemplateAction[i].channel).toString()]: {} })
            }
            if (!this.templateData1[(this.form.value.CampaignTemplateAction[i].channel).toString()].hasOwnProperty((this.form.value.CampaignTemplateAction[i].channelSource).toString())) {
              console.log(!this.templateData1[(this.form.value.CampaignTemplateAction[i].channel).toString()].hasOwnProperty((this.form.value.CampaignTemplateAction[i].channelSource).toString()));
              Object.assign(this.templateData1[(this.form.value.CampaignTemplateAction[i].channel).toString()], { [(this.form.value.CampaignTemplateAction[i].channelSource).toString()]: {} })
            }
            if (!this.templateData1[(this.form.value.CampaignTemplateAction[i].channel).toString()][(this.form.value.CampaignTemplateAction[i].channelSource).toString()].hasOwnProperty((element.Actionable).toString())) {
              console.log(!this.templateData1[(this.form.value.CampaignTemplateAction[i].channel).toString()][(this.form.value.CampaignTemplateAction[i].channelSource).toString()].hasOwnProperty((element.Actionable).toString()));
              Object.assign(this.templateData1[(this.form.value.CampaignTemplateAction[i].channel).toString()][(this.form.value.CampaignTemplateAction[i].channelSource).toString()], { [(element.Actionable).toString()]: {} })
            }

            this.templateData1[this.form.value.CampaignTemplateAction[i].channel][this.form.value.CampaignTemplateAction[i].channelSource][element.Actionable] = element
            // }
          });

        }
        // console.log("Bugatti", this.templateData1);
        this.loader = false;
      } else this.loader = false;
    });

  }






  addCampaign(flag) {
    // debugger;
    // this.loader = true;
    var today = new Date();
    var dd = new Date().getDate();
    var mm = new Date().getMonth() + 1;
    var yyyy = new Date().getFullYear();
    var time = today.getHours().toString() + today.getMinutes().toString();
    var uniqueIdCampaignId = 'CAMPAIGN' + dd + mm + yyyy + time;
    //console.log("3", this.channelId);
    let obj5 = {
      data:{
        "spname":"usp_unfyd_savecampaigndetails_v1",
         "parameters":{
          "json_data":{
            "campaigndetails": {
                "campaignid": uniqueIdCampaignId,
                "campaignname":this.form.value.CampaignName,
                "CampaignType":this.form.value.campaignTypeSelected,
                "description":this.form.value.CampaignDesc,
                "audienceListName":this.form.get('AudienceListName').value,
                "stuctureList":this.form.get('structureList').value,
                // "campaignscheduletype": this.form.value.CampaignType,
                "campaignscheduletype": this.form.value.campaignTypeSelected,
                "campaignchannelid":this.channelId,
                "targetaudiencetype":this.form.value.targetAudienceList,
                "startdatetime":this.form.value.CampaignStartDate,
                "enddatetime":this.form.value.CampaignEndDate,
                "isthrottlingenabled":this.form.value.isThrottlingEnabled == true ? 1 : 0,
                "campaignsendlimit":this.form.value.campaignSendLimit,
                "campaignsendfrequency":this.form.value.campaignSendFrequency,
                "campaignsendduration":this.form.value.campaignSendDuration,
                "isapprovalneeded":"1",
                "statusid":"2",
                "createdby":"Agent",
                "campaigncategory":"test",
                "approvalstatus":"Send For Approval"
            },
            campaignconditions:[          
            ],
            campaigntemplateaction :{
              action : this.form.value.CampaignTemplateAction[0]
            }
            // fieldmapping:{
            //   "templateField":this.form.value.fieldMapping
            // },
          }
        }
      }
    }



    
console.log("pintu", obj5);









  
    this.form.value.condition.forEach((element,i) => {
      let obj:any = {}
      Object.assign(obj,{conditionname:element.conditionName})
      Object.assign(obj,{subcondition:element.subcondition})
      Object.assign(obj,{action:element.action})
      // Object.assign(obj,{fieldMapping:element.action[i].forEach((elem:any,i:any)=>{
      //        console.log(elem);
      //         //  console.log(element.action);
      //          console.log(i);
      //       // console.log(element.action[i]);
      //        Object.assign(elem, {...this.form.value.fieldMapping[i]});
      //         console.log(Object.assign(elem, {...this.form.value.fieldMapping[i]}));
      //       //  let xyz =  obj5.data.parameters.json_data.campaignconditions[i].action
      //       //  console.log(xyz);         
      // })})
      this.form.value.fieldMapping[i].action.forEach((elementj,j) => {
        Object.assign(obj.action[j],{'fieldMapping':this.form.value.fieldMapping[i].action[j].hsmSelected})
      });
      obj5.data.parameters.json_data.campaignconditions.push(obj)
    });
    
    console.log("obj5",obj5);
    
    // this.api.dynamicDashboard('https://nipunuat.unfyd.com:3001/api/pitch/json/index', obj5).subscribe((res: any) => {
    //   if (res.code == 200) {
    //     this.loader = false;
    //     this.campaginData = res.results.data;
    //     this.audienceFieldListNameArray=[];
    //     this.form.patchValue(obj5);
    //     this.common.snackbar('Campaign saved successfully','success');
    //     console.log('oneTwoThree',this.campaginData);
    //      this.router.navigate([`/pitch/campaign/list`]);
    //     // this.router.navigateByUrl('/pitch/campaign/list');
    //   }
    // },
    //   (error) => {
    //     this.common.snackbar("General Error");
    //   })
  }


  
  obj(arg0: string, obj: any) {
    throw new Error('Method not implemented.');
  }
  
  callDialog(i, j, channelId, channelSRCID, language, CampaignTemplateAction?) {

    // if (type == "EnglishTemplate") {
    // console.log("channel:- ", channelId, "channel source:- ", channelSRCID, language)
    const dialogRef = this.dialog.open(PitchDialogComponent, {
      data: {
        type: 'hsmTemplate',
        // langCode: ,
        channelSRCID,
        channelId,
        language
      },
      width: "900px",
      height: "88vh"
    });
    dialogRef.afterClosed().subscribe(status => {
      if (status.status) {
        console.log("testStatus", status);
        if (CampaignTemplateAction) {
          // let a = this.form.value.CampaignTemplateAction.hsmSelected
          let a = this.form.value.CampaignTemplateAction[i].hsmSelected
          console.log(a)
          a[language] = status.data['Template Name']
          // console.log("a.",a)
          this.actionableId = status.data.Actionable

          // this.getActionTemplate()['controls'][i]['controls']['hsmSelected'].patchValue(a);
          // this.addFieldMapping(i, j, language)
          // let b = status.data.Parameters.replace('^',',')
          // this.form.controls['CampaignTemplateAction']['controls'][i]['controls']['fieldMapping'].addControl(language, new FormArray([]))
          let fieldMappingControl = this.form.controls['CampaignTemplateAction']['controls'][i]['controls']['fieldMapping'] as FormGroup
          fieldMappingControl.addControl(language, new FormArray([]))
          console.log("fildMapping", fieldMappingControl)
          let b = status.data.Parameters;
          b.split("^").forEach((element, index) => {
            this.addfieldMappingAction1Obj(element);

            this.form.controls['CampaignTemplateAction']['controls'][i]['controls']['fieldMapping']['controls'][language].push(this.formBuilder.group({
              key: [element, [Validators.required]],
              value: ['', [Validators.required]],
            }))
            console.log("fildMapping1", this.form.value);

            // this.form.value.CampaignTemplateAction[i].fieldMapping
            // this.addFieldMappingObj(i, j, language)
            // this.patchFieldMappingObj(i, j, language, index, element)
            this.form.updateValueAndValidity()
          });
          console.log(this.form.value)

          this.conditionIndex = i
          this.actionIndex = j
          this.languageSelected = language


        } else {
          let a = this.form.value.condition[i].action[j].hsmSelected
          console.log(a)
          a[language] = status.data['Template Name']
          console.log("a.", a)
          this.actionableId = status.data.Actionable
          // this.actionableId = status.data.TemplateName
          // console.log(a);
          this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(a);
          this.addFieldMapping(i, j, language)
          console.log("actionfildmapping1", this.addFieldMapping)
          // let b = status.data.ParameterValue.replace('^',',')
          let b = status.data.Parameters;
          b.split("^").forEach((element, index) => {
            this.addFieldMappingObj(i, j, language)
            this.patchFieldMappingObj(i, j, language, index, element)
          });
          a[language] = status.data.Actionable
          this.conditionIndex = i
          this.actionIndex = j
          this.languageSelected = language
          // console.log("lllll:", b);

          console.log(this.form.value);
        }
      }
    });
    // }

    // if (type == "campaignApproval") {
    //   const dialogRef = this.dialog.open(PitchDialogComponent, {
    //     data: {
    //       type: 'campaignApproval',
    //     },
    //     width: "400px",
    //     height: "40vh"
    //   });
    //   dialogRef.afterClosed().subscribe(status => {
    //     if (status == true) {

    //     }
    //   });
    // }

  }

  closeDialog(status: any): void {

  }

  returnSRC(channel,channelSource,id){
    id = this.actionableId;  
    if(channel && channelSource && id) 
    return this.templateData[channel]?.[channelSource]?.[id]?.MessageHeaderValue
  }
  returnSRC1(channel, channelSource, id) {
    id = this.actionableId;
    if (channel && channelSource && id)
      // console.log("templatedata1",this.templateData1[channel]?.[channelSource]?.[id]?.["Message Header Value"])
      return this.templateData1[channel]?.[channelSource]?.[id]?.["Message Header Value"]
  }
  

  addFieldMapping(i,j,language){
    // this.f2.addControl(i,this.formBuilder.group({}))
    //console.log(this.form);
    
  }


  visibleFieldMapping(){
    // setTimeout(() => {
      if(this.conditionIndex == undefined || this.actionIndex == undefined){return false}
      return this.conditionIndex.toString() && this.actionIndex.toString() && this.languageSelected
    // });
  }

  getdurationlist() {
    var Obj1 = {
      data: {
        spname: "usp_unfyd_getdurationlist",
        parameters: {
         
        }
      }
    }

    this.api.post('pitch/index', Obj1).subscribe(res => {
      if (res.code == 200) {
        //console.log(res);
        this.sendEmailDur = res.results.data;
        //console.log(this.sendEmailDur);
        
      }
    })
  }

  openAudienceListDialog() {
    const dialogRef = this.dialog.open(PitchDialogComponent, {
      data: {
        type: "getAudienceList"
      },
      disableClose: true,
      height: '85%',
      width: '85%'
    });
  }

  pageReload(){ 
    document.getElementById("rotating").classList.add("rotating");
    setTimeout(()=>{
      window.location.reload();
      document.getElementById("rotating").classList.remove("rotating");
    },1000)
  }

  copyInputMessage(inputElement){
    inputElement.select();
    document.execCommand('copy');
    inputElement.setSelectionRange(0, 0);
  }

  selectedStructureField(val){
    console.log("value")

    this.structureListArr.forEach(element => {
      if(element.Id == val){
        this.selectedStructure = JSON.parse(element.StructureJson)
        console.log(this.selectedStructure);
        
      }
    });
  }


  abcd(ii,lang){
    if((this.form['controls']['CampaignTemplateAction']['controls'][ii]['controls']['fieldMapping'].value).hasOwnProperty(lang))
    return this.form['controls']['CampaignTemplateAction']['controls'][ii]['controls']['fieldMapping']['controls'][lang]['controls'] as FormArray
  }

  actionTemplateIndex = 0
  actionTemplateLang = 'en'
  actionTemplateSelected(i,lang){
    this.actionTemplateIndex = i
    this.actionTemplateLang = lang
  }
  
  ngOnDestroy(): void {
    
  }

}
