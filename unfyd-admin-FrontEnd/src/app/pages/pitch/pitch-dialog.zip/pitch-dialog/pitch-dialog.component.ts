import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subject } from 'rxjs/internal/Subject';
import { ApiService } from 'src/app/global/api.service';
import { AuthService } from 'src/app/global/auth.service';
import { CommonService } from 'src/app/global/common.service';

@Component({
  selector: 'app-pitch-dialog',
  templateUrl: './pitch-dialog.component.html',
  styleUrls: ['./pitch-dialog.component.scss']
})
export class PitchDialogComponent implements OnInit {

  requestObj: {};
  masters: any;
  addAlert: any;
  sendEmail: any;
  minDate1 = new Date();
  maxDate1 = new Date();
  dateObj: any;
  readonly imageTrigger: Subject<void> = new Subject<void>();
  croppedImage: any;
  uploadWithForm: boolean = true;
  cropPanel: boolean = false;
  minDateDeposit = new Date();
  form: FormGroup;
  formChangePassword: any;
  submittedForm: boolean = false;
  loaderSmall: boolean = false;
  disabled: boolean = true;
  category: any = '';
  channelname: any = '';
  whatsappicon: any = '';
  // reset: boolean;
  file: any;
  fileName: any = '';
  imageUrl: any;
  extention: any;
  imgPreview: any = '';
  QRdata: any;
  saveJson: boolean = true;
  hide = true;
  hide1 = true;
  hide2 = true;
  isDropDown: boolean;
  totalCollection: number = 0;
  inbound: FormGroup;
  outbound: FormGroup;
  req: { data: { spname: string; parameters: { flag: string; processid: any; }; }; };
  Icon: string;
  deletePopup: boolean;
  profileImg: any = null;
  person: any = null;
  errorImg: any = null;
  checkImg: any = null;
  substring: string = '';
  abc: any;
  masterConfig: any
  loader: boolean;
  GST: any;
  userDetails: any;
  tabData: number;
  tabKey: any = [];
  noData: boolean = true;
  page: number = 1;
  itemsPerPage: number = 10;
  search: any;
  userConfig: any
  type: any;
  selctedField: any[] = [];
  unSelctedField: any[] = [];
  finalField: any[] = [];
  tabValue = [];
  push: any;
  channelType: any;
  whatsappchanelform: FormGroup;
  disableInput: FormGroup;
  paginationArray: any = [];
  tempRes: any = [];
  tempKey: any = [];
  commonObj: any;
  path: any;
  editObj: any;
  languageType: any = [];
  states: any = [];
  filteredstates = this.states.slice();
  labelName: any;
  lastYear = new Date();
  regex: any;
  skillId: any;
  modules: any;
  configData: any;
  location: any;
  updateModules: any;
  addBtn: boolean;
  formOnlineHrs: FormGroup;
  unfydMaster: any;
  formData: any;
  formName: any;
  formOfflineDays: FormGroup;
  masterSelected: boolean;
  checklist: { id: number; value: string; isSelected: boolean; }[];
  checkedList: any;
  item: any;
  categoryImg: any;
  loginLoader: boolean = false;
  loginImg: any;
  isDisabled = false;
  check: boolean = false;
  serviceContract: any;
  cities: any;
  parentAccount: any;
  profilepic: any = null;
  editobj: any;
  dateFormat: any;
  products: any;
  icons: string;
  channel: any;
  channelSource: any;
  custom: any;
  skill: any;
  UID: any;
  Rule: any;
  accessControlsLst: any;
  actionname: any;
  agents: any;
  skillType: any;
  getGroupList: any;
  rule: any;
  channelvalue: any;
  RMType: any;
  customtype: any;
  description: any;
  roleid: any;
  productid: any;
  isnot: boolean = false;
  errorvalue: any;
  securitycomplainceresponse: boolean = false;
  PasswordStrength: any;
  PasswordStrengthval: any = false;
  tenantproid: any;
  ConfigValue: any;
  passwordmatch: boolean = false;
  passwordNotMatchval: boolean = false;
  hsmbody: any;
  totalItems = 0
  drilldownURL
  drilldownRequest
  localizationData = []
  languagesByTenant = []
  defaultLabels = []
  panelOpenState = false

  constructor(
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<PitchDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public common: CommonService,
    private auth :  AuthService,
    private api : ApiService
  ) { }

  ngOnInit(): void {
    this.userDetails = this.auth.getUser();
    if (this.data.type == 'hsmTemplate') {
      Object.assign(this.data,{tabValue:[]})
      this.getHsmTemplate();
    }
  }

  closeDialog(status: any): void {
    this.common.hubControlEvent(this.data.type, 'click', '', '', JSON.stringify(status), 'closeDialog');

    this.dialogRef.close(status);
    if (this.data.type == "addPriv") {
      this.common.reloadDataMethod(true);
    }
    //this.common.closePopupvalues(status, this.category, this.imageUrl);
    if (this.data?.data?.data?.icon != undefined && this.data?.data?.data?.icon != null) {
      this.common.closePopupDeleteImg(this.data.data.data.icon)
    }
  }

  sendDataToNotification(data) {
    this.dialogRef.close({ status: true, data: data });
    console.log("s:", data);
  }

  getHsmTemplate() {
    this.loader = true;
    let obj = {
      "data": {
        "spname": "usp_unfyd_hsm_template",
        "parameters": {
          "FLAG": "GET_HSM",
          "PROCESSID": this.userDetails.Processid,
          "CHANNELID": this.data.channelId,
          "UNIQUEID": this.data.channelSRCID
        }
      }
    }

    this.api.post('index', obj).subscribe((res) => {
      if (res.code == 200) {
        console.log("response", res);
        this.loader = false;
        Object.assign(this.data,{tabValue:res.results.data})
      }
    });

  }
  
}
