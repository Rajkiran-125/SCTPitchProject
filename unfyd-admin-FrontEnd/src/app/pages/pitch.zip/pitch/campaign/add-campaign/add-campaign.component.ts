import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from 'src/app/global/api.service';
import { AuthService } from 'src/app/global/auth.service';
import { CommonService } from 'src/app/global/common.service';
import { MatDialog } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { PitchDialogComponent } from '../../pitch-dialog/pitch-dialog.component';
import { ExcelService } from 'src/app/global/excel.service';

@Component({
  selector: 'app-add-campaign',
  templateUrl: './add-campaign.component.html',
  styleUrls: ['./add-campaign.component.scss']
})
export class AddCampaignComponent implements OnInit {
  formName: any;
  selectedTab: any;
  form: FormGroup;
  excelFileUpload: any = [];
  conditionForm: FormGroup;
  userDetails: any;
  requestObj: any;
  language: any;
  botFlowList: any;
  submittedForm: boolean = false;
  loader: boolean = false;
  formData: any = null;
  path: any;
  channelSRCID: any;
  productId: any;
  TemplateData: any = [];
  sampleExcelData: any = [{
    "Sr.No": "",
    "Campaign Name": "",
    "Campaign Type": "",
    "Channel": ""
  }];
  sendEmailDur: any = [
    {"Key": "Minutes", "Value":"Mins"},
    {"Key": "Hours", "Value":"Hrs"}
  ]
  channelSourceAvailable: boolean = false;
  templateID: any;
  template: any = [];
  subscription: Subscription[] = [];
  SampleCampaignExcel: any = [];
  Conditonsdata: any = [];
  templateVisible: boolean = false;
  cardTemplate: any;
  campaginData: any;
  config: any;
  time = { hour: 0, minute: 0, second: 0 }
  ChannelSource: any = [];
  Channel: any;
  Sender: any;
  temp: any;
  campaignType: any[] = [
    {"Key": "OneTime", "Value":"One Time"},
    {"Key": "Recurring", "Value":"Recurring"}
  ];
  campaignTime: any[] = [
    {hour:0, minute:0,second:0}
  ]
  configdata: any;
  showThrottling: any = false;
  templateData: any = {};
  fileData: any;
  ObjectKeys = Object.keys
  conditionIndex :number
  actionIndex :number
  languageSelected :string
  excelFileName: any;
  //campaignTypeSelected: any;

  constructor(
    private api: ApiService,
    private formBuilder: FormBuilder,
    public common: CommonService,
    private excelService: ExcelService,
    private auth: AuthService,
    public datepipe: DatePipe,
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog) { }

  ngOnInit(): void {
    this.userDetails = this.auth.getUser();
    this.path = this.activatedRoute.snapshot.paramMap.get('id');
    this.channelSRCID = this.activatedRoute.snapshot.paramMap.get('uniqueid');
    this.productId = this.activatedRoute.snapshot.paramMap.get('productId');
    // this.type = this.activatedRoute.snapshot.paramMap.get('type');
    this.getLanguage();
    this.getChannel();
    // this.callDialog()
    this.form = this.formBuilder.group({

      CampaignName: ['', [Validators.required]],
      CampaignDesc: ['', [Validators.required]],
      CampaignTemplate: ['', [Validators.required]],
      CampaignType: ['One Time', [Validators.required]],
      ChannelList: ['Whatsapp', [Validators.required]],
      campaignTypeSelected: ['', [Validators.required]],
      ChannelSrc: ['', [Validators.required]],
      toggleMultilingual: ['', [Validators.required]],
      targetAudienceList: ['ImportNew', [Validators.required]],
      headerType: ['', [Validators.required]],
      AudienceListName: ['', [Validators.required]],
      CampaignStartDate: ['', [Validators.required]],
      CampaignEndDate: ['', [Validators.required]],
      campaignSendLimit: ['', [Validators.required]],
      campaignSendFrequency: ['', [Validators.required]],
      campaignSendDuration: ['', [Validators.required]],
      pollingTimer: [{ hour: 0, minute: 0, second: 0 }, [Validators.required]],
      pollingUrlBody: [{ hour: 0, minute: 0, second: 0 }, [Validators.required]],
      pollingHeaderKey: [{ hour: 0, minute: 0, second: 0 }, [Validators.required]],
      pollingHeaderValue: [{ hour: 0, minute: 0, second: 0 }, [Validators.required]],
      condition: this.formBuilder.array([this.addCondition()]),
      // getAndOrCondition: ['', [Validators.required]],
      // languageSelected: [[], Validators.nullValidator],
      audienceListField: ['', [Validators.required]],
      fieldMapping:this.formBuilder.array([this.addFMCondition()])
    })

    setTimeout(() => {
      console.log(this.form)
    }, 5000);

    this.common.setMasterConfig();
    this.subscription.push(
      this.common.getMasterConfig$.subscribe((data) => {
        debugger;
        if (Object.keys(data).length > 0) {
          this.SampleCampaignExcel = JSON.parse(data["SampleCampaignExcel"]);
          this.Conditonsdata = JSON.parse(data["Conditionscampaign"]);
          
          if(this.SampleCampaignExcel.length > 0){
            let obj = {}
            this.SampleCampaignExcel.forEach(el => {  
              Object.assign(obj, {[el.Key]: ''});
            });
            this.sampleExcelData = [obj];
            // console.log("helloooooo:", this.sampleExcelData);            
          }
          
          if(this.Conditonsdata.length > 0){
            let obj123 = {}
            this.Conditonsdata.forEach(el => {  
              Object.assign(obj123, {[el.Key]: ''});
            });
            this.Conditonsdata = [obj123];
          }
        }
      })
    )
  }

  getAndOrCondition(value) {
    console.log('Hello :', value);
  }
  selectLan(value,i,j) {
    console.log('Language :', value);
    if(value.length > 0){
      if(Object.keys(this.form.value.condition[i].action[j].hsmSelected).length > 0){
        console.log(Object.keys(this.form.value.condition[i].action[j].hsmSelected));
        // delete value which is not in language
        let valuesInHSMSelected = Object.keys(this.form.value.condition[i].action[j].hsmSelected).filter(x => !value.includes(x))
        console.log(valuesInHSMSelected)
        let obj1 = this.form.value.condition[i].action[j].hsmSelected
        if(valuesInHSMSelected.length > 0){
          valuesInHSMSelected.forEach(el => {
            delete obj1[el]
            // this.getFMAction(i)['controls']['action']['controls'][j]['controls']['hsmSelected'].removeControl(el)
            this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected'].removeControl(el)
          })
          this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(obj1)
        }
                  
        //add value 
        let valuesInHSMSelected1 = value.filter(x => !Object.keys(this.form.value.condition[i].action[j].hsmSelected).includes(x))
        console.log(valuesInHSMSelected1)
        let obj2 = this.form.value.condition[i].action[j].hsmSelected
        if(valuesInHSMSelected1.length > 0){
          valuesInHSMSelected1.forEach(el => {
            Object.assign(obj2,{[el]:''})
            this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected'].addControl(el,this.formBuilder.array([]))
          })
          this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(obj2)
        }
      }else{
        let obj = {}
        value.forEach(element => {
          Object.assign(obj,{[element]:''})
          this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected'].addControl(element,this.formBuilder.array([]))
        });
        this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(obj);        
      }      
    } else{
      let obj = Object.keys(this.form.value.fieldMapping[i].action[j].hsmSelected)
      if(obj.length > 0){
        this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected'].removeControl(obj)
      }
      this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue({});  
    }
    console.log(this.form);
    console.log(this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected'])
    

  }

  addMoreCondition() {
    this.f1.push(this.addCondition())
    this.f2.push(this.addFMCondition())
  }

  get f1() { return this.form.get('condition') as FormArray }
  get f2() { return this.form.get('fieldMapping') as FormArray }
  getCondition(): FormArray {
    return this.form.get('condition') as FormArray;
  }
  getSubCondition(index): FormArray {
    return this.getCondition().at(index).get('subcondition') as FormArray;
  }
  getAction(index): FormArray {
    return this.getCondition().at(index).get('action') as FormArray;
  }
  getFMCondition(): FormArray {
    return this.form.get('fieldMapping') as FormArray;
  }
  getFMAction(index): FormArray {
    return this.getFMCondition().at(index).get('hsmSelected') as FormArray;
  }
  getfieldMapping(){
    return this.form.get('fieldMapping') as FormArray;
  }
  getfieldMappingAction(index): FormArray {
    // console.log(this.getFMCondition().at(index));
    return this.getFMCondition().at(index).get('action') as FormArray;
  }
  getfieldMappingHsmSelected(i,j): FormGroup {
    //console.log("hsmSelected:",this.getfieldMappingAction(i).at(j).get('hsmSelected'));
    return this.getfieldMappingAction(i).at(j).get('hsmSelected') as FormGroup;
  }
  getfieldMappingLanguage(i,j,language): FormArray {
    //console.log(language,":",this.getfieldMappingAction(i).at(j).get('hsmSelected').get(language));
    return this.getfieldMappingAction(i).at(j).get('hsmSelected').get(language) as FormArray;
  }
  getFMField(): FormArray {
    // console.log(this.form.controls['fieldMapping']['controls'][this.conditionIndex]['controls']['action']['controls'][this.actionIndex]['controls']['hsmSelected']['controls'][this.languageSelected]['controls']);
    
    return this.form.controls['fieldMapping']['controls'][this.conditionIndex]['controls']['action']['controls'][this.actionIndex]['controls']['hsmSelected']['controls'][this.languageSelected]['controls'] as FormArray;
    // return this.getFMAction(this.conditionIndex).at(this.actionIndex).get('hsmSelected').get(this.languageSelected) as FormArray
  }
  
  createFMAction(index){
    this.getFMAction(index).push(this.addFMAction())
  }
  addCondition(): FormGroup {
    return this.formBuilder.group({
      conditionName: ['', Validators.required],
      // Channel: ['', Validators.required],
      // ChannelSource: ['', Validators.nullValidator],
      subcondition: this.formBuilder.array([this.addSubCondition()]),
      action: this.formBuilder.array([this.addAction()])
    })
  }
  addFMCondition(): FormGroup {
    return this.formBuilder.group({
      action: this.formBuilder.array([this.addFMAction()])
    })
  }

  addFMAction(): FormGroup {
    return this.formBuilder.group({
      hsmSelected: this.formBuilder.group({}),
    })
  }

  addFMField(): FormGroup {
    return this.formBuilder.group({
      campaignField: '',
      attributeMappingField: '',
    })
  }

  addFieldMappingObj(i,j,language){
    this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected']['controls'][language].push(this.addFMField())
  }
  patchFieldMappingObj(i,j,language,index,campaignField){
    this.form.controls['fieldMapping']['controls'][i]['controls']['action']['controls'][j]['controls']['hsmSelected']['controls'][language]['controls'][index]['controls']['campaignField'].patchValue(campaignField)
  }


  addAction(): FormGroup {
    return this.formBuilder.group({
      channel: ['', Validators.required],
      channelSource: ['', Validators.nullValidator],
      languageSelected: [[], Validators.nullValidator],
      hsmSelected: [{}, Validators.nullValidator],
    })
  }

  addSubCondition(): FormGroup {
    return this.formBuilder.group({
      field: ['', Validators.required],
      subcondition: ['', Validators.nullValidator],
      conditionvalue: ['', Validators.nullValidator],
      getAndOrCondition: ['', Validators.nullValidator],
    })
  }

  campaignConditions(): FormArray {
    return this.conditionForm.get('conditions') as FormArray;
  }

  newConditon(): FormGroup {
    return this.formBuilder.group({
      ConditonNameSelected: ['', [Validators.required]],
      SelectedField: ['', [Validators.required]],
      SelectedCondition: ['', [Validators.required]],
      SelectedConditionValue: ['', [Validators.required]],
      SelectedFieldOne: ['', [Validators.required]],
      SelectedConditionOne: ['', [Validators.required]],
      SelectedConditionValueOne: ['', [Validators.required]],
      subcondition: this.formBuilder.array([]),
      action: [''],
      
    });
  }


  newAction(): FormGroup {
    return this.formBuilder.group({
      SelectedChannel: ['', [Validators.required]],
      SelectedChannelSource: ['', [Validators.required]],
      languageSelected: ['', [Validators.required]]
    });
  }


  createAction(index){
    this.getAction(index).push(this.addAction())
    this.getFMAction(index).push(this.addFMAction())
  }
  createSubCondition(index){
    this.getSubCondition(index).push(this.addSubCondition())
  }

  removeAction(conditionIndex,actionIndex){
    this.getAction(conditionIndex).removeAt(actionIndex)
  }

  removeSubCondition(conditionIndex,actionIndex){
    this.getSubCondition(conditionIndex).removeAt(actionIndex)
  }

  downloadSampleExcel(){
    this.excelService.exportExcel(this.sampleExcelData, ('Pitch_Sample_Format').toUpperCase());
  }

  resetfunc() {
    this.form.reset();
  }

  getChannel() {
    this.requestObj = {
      data: {
        spname: "usp_unfyd_getdropdowndetails",
        parameters: {
          flag: "CHANNEL",
          processid: this.userDetails.Processid,
        }
      }
    };
    this.api.post('index', this.requestObj).subscribe((res: any) => {
      if (res.code == 200) {
        this.Channel = res.results.data;
      }
    });
  }

  getSenderData(channel, sourceId) {
    this.loader = true;
    let channelData = this.Channel.filter(obj => {
      if (obj.ChannelId === channel) {
        return obj;
      }
    });
    if (channelData[0].ChannelName === 'WhatsApp') {
      this.requestObj = {
        data: {
          spname: "USP_UNFYD_NOTIFICATION",
          parameters: {
            flag: 'GET_CONTACT_NUMBER',
            CHANNELSOURCE: sourceId
          }
        }
      };
      this.api.post('index', this.requestObj).subscribe(res => {
        if (res.code == 200) {
          res.results.data.forEach(element => {
            this.Sender.push({ Key: element.WhatsAppNumber, Value: element.WhatsAppNumber })
          });
          this.loader = false;
        } else this.loader = false;
      });
    } else this.loader = false;
  }

  getFields(event) {
    this.TemplateData = [];
    this.template = [];
    this.templateVisible = false;
    this.cardTemplate = [];
    this.form.get('ChannelSource').reset();
    this.form.get('Template').reset();
    this.form.updateValueAndValidity();
    // let channel = this.Channel.filter(obj => {
    //   if (obj.ChannelId === event) {
    //     return obj;
    //   }
    // });
    // if (channel[0].ChannelName === 'Email') {
    //   this.emailChannel = true;
    //   this.whatsAppChannel = false;
    // } else if (channel[0].ChannelName === 'WhatsApp') {
    //   this.whatsAppChannel = true;
    //   this.emailChannel = false;
    // } else {
    //   this.emailChannel = false;
    //   this.whatsAppChannel = false;
    // }
  }
  getLanguage() {
    this.requestObj = {
      data: {
        spname: "usp_unfyd_tenant",
        parameters: {
          flag: "GET_LANGUAGE_DATA",
          processid: this.userDetails.Processid
        }
      }
    }
    this.api.post('index', this.requestObj).subscribe(res => {
      if (res.code == 200) {
        this.language = res.results.data;
      }
    })
  }

  UploadChatIcon(event, max_width, max_height) {
    var file = event.target.files[0];
    var size = Math.round(file.size / 1024);
    var extension = file.type;
    const formData = new FormData();
    var filename = this.userDetails.Id + '_webchat_' + this.datepipe.transform(new Date(), 'ddMMyyhhmmss');
    formData.append(filename, file);

    if (size > 2000) {
      this.common.snackbar("File Size");

    } else if (extension !== 'image/jpeg' && extension !== 'image/jpg' && extension !== 'image/png' && extension !== 'image/gif') {
      this.common.snackbar("File Type");
    } else {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        const image = new Image();
        image.src = e.target.result;
        image.onload = rs => {
          const img_height = rs.currentTarget['height'];
          const img_width = rs.currentTarget['width'];

          if (img_height > max_height && img_width > max_width) {
            this.common.snackbar("FileReso");
          } else {
            this.loader = true;
            this.api.post('upload', formData).subscribe(res => {
              if (res.code == 200) {
                this.form.controls['chatIconUploaded'].patchValue(res.results.URL);
                this.loader = false;
              } else {
                this.loader = false;
              }
            }, error => {
              this.loader = false;
            });
          }
        };
      };
      reader.readAsDataURL(file);
    }
  }

  
  UploadCampaignExcel(event) {
    var file = event.target.files[0];
    var size = Math.round(file.size / 1024);
    var extension = file.type;
    const formData = new FormData();
    var filename = this.userDetails.Id + '_Campaign_' + this.datepipe.transform(new Date(), 'ddMMyyhhmmss');
    formData.append(filename, file);
    console.log("there", extension);
    
    // if (size > 5000) {
    //   this.common.snackbar("File Size");


    // } else if (extension !== 'image/jpeg' && extension !== 'image/jpg' && extension !== 'image/png' && extension !== 'image/gif') {
    //   this.common.snackbar("File Type");
    // } else {
    //   const reader = new FileReader();
    //   reader.onload = (e: any) => {
    //     this.excelService.importExcel(event)        
    //   };
    //   reader.readAsDataURL(file);
    // }

    let filetype = event.target.files[0].type
    if (filetype == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
      this.excelService.importExcel(event);
      console.log('test', this.excelService.getJson());
      
      if(this.excelService.getJson()){
        
        this.temp = JSON.parse(JSON.stringify(this.excelService.getJson()));
        this.excelFileUpload.push({name:filename,status:false,file:file,data:this.temp})
    }
      console.log("suyog", this.temp);
    }
    else {
      this.common.snackbar('Please Upload ".xlsx" format file', 'error');
      return
    }
  }

  uploadExcelFiles(){
    // var file = event.target.files;
    if(this.excelFileUpload.length > 0){
      this.excelFileUpload.forEach(element => {
        if (!element.status) {
          const formData = new FormData();
          this.excelFileName = element.name;
          var filename = element.name;
          formData.append(filename, element.file);
          this.loader = true;
          element.status = 'uploading'
          this.api.post('pitch/upload', formData).subscribe(res => {
            if (res.code == 200) {
              element.status = true;
              console.log("vishal:", res);
              this.showThrottling = true;
              this.loader = false;
            }
          })
        }
      });
    } else if(this.excelFileUpload.length == 0){
      this.common.snackbar('Please choose at least one excel file', 'error');
    }
  }
  addCampaign(flag) {
    debugger;
    var today = new Date();
    var dd = new Date().getDate();
    var mm = new Date().getMonth() + 1;
    var yyyy = new Date().getFullYear();
    var time = today.getHours().toString() + today.getMinutes().toString();
    var uniqueIdCampaignId = 'CAMPAIGN' + dd + mm + yyyy + time;
    let obj5 = {
      data:{
        "spname":"usp_unfyd_savecampaigndetails_v1",
         "parameters":{
          "json_data":{
            "campaigndetails": {
                "campaignid": uniqueIdCampaignId,
                "campaignname":this.form.value.CampaignName,
                "description":this.form.value.CampaignDesc,
                "campaignscheduletype": this.form.value.CampaignType,
                "campaignchannelid":"1",
                "targetaudiencetype":this.form.value.targetAudienceList,
                "startdatetime":this.form.value.CampaignStartDate,
                "enddatetime":this.form.value.CampaignEndDate,
                "isapprovalneeded":"1",
                "statusid":"1",
                "createdby":"Agent",
                "campaigncategory":"test",
                "approvalstatus":"Send For Approval"
            },
            targetaudiencetype:{

            },
            campaignconditions:[          
            ]
          }
        }
      }
    }

    this.form.value.condition.forEach(element => {
      let obj:any = {}
      Object.assign(obj,{conditionname:element.conditionName})
      Object.assign(obj,{subcondition:element.subcondition})
      Object.assign(obj,{action:element.action})
      obj5.data.parameters.json_data.campaignconditions.push(obj)
    });
    console.log("obj5",obj5);
    
    this.api.dynamicDashboard('https://nipunuat.unfyd.com:3001/api/pitch/json/index', obj5).subscribe((res: any) => {
      if (res.code == 200) {
        this.loader = false;
        this.campaginData = res.results.data;
        this.form.patchValue(obj5);
        this.common.snackbar('Campaign saved successfully','success');
        console.log('oneTwoThree',this.campaginData);
      }
    },
      (error) => {
        this.common.snackbar("General Error");
      })
  }


  getChannelSource(i,j,ChannelId) {
    this.loader = true;
    this.requestObj = {
      data: {
        spname: "USP_RULEMASTER_PROC",
        parameters: {
          flag: "CHANNELSOURCE",
          channelid : this.form.value.condition[i].action[j].channel,
          processid: this.userDetails.Processid
        }
      }
    };
    console.log("Hey", this.requestObj);
    
    this.api.post('index', this.requestObj).subscribe((res: any) => {
      if (res.code == 200) {        
        this.ChannelSource = res.results.data;
        //console.log("vishal", res);
        this.loader = false;
      } else this.loader = false;
    });
  }

  getTemplate(i,j,event) {
  
     let obj = {
     data: {      
      spname: "usp_unfyd_hsm_template",      
      parameters: {      
       FLAG: "GET_HSM",
       PROCESSID: this.userDetails.Processid,
       CHANNELID: this.form.value.condition[i].action[j].channel,
       UNIQUEID: this.form.value.condition[i].action[j].channelSource
       }
     }
     
    };
    console.log("chiron", obj);

    this.api.post('index', obj).subscribe((res: any) => {
      if (res.code == 200) {
        // this.templateData[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource] = res.results.data;
        if(res.results.data.length > 0){
          res.results.data.forEach(element => {
            // if(Object.keys(this.templateData[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource]).includes(element.Actionable)){
              if(!this.templateData.hasOwnProperty((this.form.value.condition[i].action[j].channel).toString())){
                Object.assign(this.templateData,{[(this.form.value.condition[i].action[j].channel).toString()]:{}})
              }
              if(!this.templateData[(this.form.value.condition[i].action[j].channel).toString()].hasOwnProperty((this.form.value.condition[i].action[j].channelSource).toString())){
                Object.assign(this.templateData[(this.form.value.condition[i].action[j].channel).toString()],{[(this.form.value.condition[i].action[j].channelSource).toString()]:{}})
              }
              if(!this.templateData[(this.form.value.condition[i].action[j].channel).toString()][(this.form.value.condition[i].action[j].channelSource).toString()].hasOwnProperty((element.Actionable).toString())){
                Object.assign(this.templateData[(this.form.value.condition[i].action[j].channel).toString()][(this.form.value.condition[i].action[j].channelSource).toString()],{[(element.Actionable).toString()]:{}})
              }
              
              this.templateData[this.form.value.condition[i].action[j].channel][this.form.value.condition[i].action[j].channelSource][element.Actionable] = element
            // }
          });

        }
        console.log("Bugatti", this.templateData);
        this.loader = false;
      } else this.loader = false;
    });
    
}
  obj(arg0: string, obj: any) {
    throw new Error('Method not implemented.');
  }
  callDialog(i,j,channelId,channelSRCID,language) {

    // if (type == "EnglishTemplate") {
      const dialogRef = this.dialog.open(PitchDialogComponent, {
        data: {
          type: 'hsmTemplate',
          // langCode: ,
          channelSRCID,
          channelId,
          language
        },
        width: "900px",
        height: "88vh"
      });
      dialogRef.afterClosed().subscribe(status => {
        if (status.status) {
            console.log("testStatus", status);   
            let a = this.form.value.condition[i].action[j].hsmSelected
            a[language] = status.data.Actionable
            this.getAction(i)['controls'][j]['controls']['hsmSelected'].patchValue(a);
            this.addFieldMapping(i,j,language)
            let b = status.data.ParameterValue.replace('^',',')
            b.split(",").forEach((element,index) => {
              this.addFieldMappingObj(i,j,language)
              this.patchFieldMappingObj(i,j,language,index,element)
            });
            this.conditionIndex  = i
            this.actionIndex  = j
            this.languageSelected  = language
            console.log("lllll:",b);
            
            console.log(this.form.value);
            
        }
      });
    // }

    // if (type == "campaignApproval") {
    //   const dialogRef = this.dialog.open(PitchDialogComponent, {
    //     data: {
    //       type: 'campaignApproval',
    //     },
    //     width: "400px",
    //     height: "40vh"
    //   });
    //   dialogRef.afterClosed().subscribe(status => {
    //     if (status == true) {

    //     }
    //   });
    // }

  }

  closeDialog(status: any): void {

  }

  returnSRC(channel,channelSource,id){
    if(channel && channelSource && id)
    return this.templateData[channel][channelSource][id].MessageHeaderValue
  }
  

  addFieldMapping(i,j,language){
    // this.f2.addControl(i,this.formBuilder.group({}))
    console.log(this.form);
    
  }


  visibleFieldMapping(){
    // setTimeout(() => {
      if(this.conditionIndex == undefined || this.actionIndex == undefined){return false}
      return this.conditionIndex.toString() && this.actionIndex.toString() && this.languageSelected
    // });
  }

}
