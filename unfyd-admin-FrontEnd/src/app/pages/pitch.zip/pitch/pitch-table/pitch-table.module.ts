import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PitchTableRoutingModule } from './pitch-table-routing.module';
import { PitchTableComponent } from './pitch-table.component';


@NgModule({
  declarations: [
    PitchTableComponent
  ],
  imports: [
    CommonModule,
    PitchTableRoutingModule
  ]
})
export class PitchTableModule { }
